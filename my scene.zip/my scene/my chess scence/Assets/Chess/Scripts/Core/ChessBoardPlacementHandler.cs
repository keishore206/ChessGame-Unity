using System;
using UnityEngine;
using System.Diagnostics.CodeAnalysis;

namespace Chess.Scripts.Core
{
    [SuppressMessage("ReSharper", "MemberCanBePrivate.Global")]
    public sealed class ChessBoardPlacementHandler : MonoBehaviour
    {
        [SerializeField] private GameObject[] _rowsArray;         // 8 rows, each with 8 tiles
        [SerializeField] private GameObject _highlightPrefab;     // Prefab for move highlight
        [SerializeField] private GameObject _enemyPrefab;         // Optional: enemy marker prefab

        private GameObject[,] _chessBoard;                         // 8x8 board grid
        internal static ChessBoardPlacementHandler Instance;

        private void Awake()
        {
            Instance = this;
            GenerateArray();
        }

        /// <summary>
        /// Builds the 8x8 board array from row GameObjects
        /// </summary>
        private void GenerateArray()
        {
            _chessBoard = new GameObject[8, 8];
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    _chessBoard[i, j] = _rowsArray[i].transform.GetChild(j).gameObject;
                }
            }
        }

        /// <summary>
        /// Returns the tile GameObject at (row, column)
        /// </summary>
        internal GameObject GetTile(int row, int col)
        {
            if (row < 0 || row >= 8 || col < 0 || col >= 8)
            {
                Debug.LogError($"Invalid tile access: ({row}, {col})");
                return null;
            }
            return _chessBoard[row, col];
        }

        /// <summary>
        /// Highlights a tile by instantiating the highlight prefab
        /// </summary>
        internal void Highlight(int row, int col)
        {
            GameObject tile = GetTile(row, col);
            if (tile == null) return;

            Instantiate(_highlightPrefab, tile.transform.position, Quaternion.identity, tile.transform);
        }

        /// <summary>
        /// Clears all highlight prefabs from the board
        /// </summary>
        internal void ClearHighlights()
        {
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    GameObject tile = _chessBoard[i, j];
                    if (tile == null || tile.transform.childCount == 0) continue;

                    foreach (Transform child in tile.transform)
                    {
                        Destroy(child.gameObject);
                    }
                }
            }
        }
    }
}