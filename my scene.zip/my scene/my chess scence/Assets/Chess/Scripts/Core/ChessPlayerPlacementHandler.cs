﻿using UnityEngine;
using Unity.Mathematics;

namespace Chess.Scripts.Core
{
    public class ChessPlayerPlacementHandler : MonoBehaviour
    {
        [SerializeField] public int row, column;
        public GameObject controller;
        private int px;
        private int py;
        public bool noPiecesOverlap = true;

        private void Start()
        {
            transform.position = ChessBoardPlacementHandler.Instance.GetTile(row, column).transform.position;
            controller = GameObject.FindGameObjectWithTag("GameController");
        }

        private void Update()
        {
            if (UnityEngine.Input.GetMouseButtonDown(0))
            {
                Ray ray = Camera.main.ScreenPointToRay(UnityEngine.Input.mousePosition);
                RaycastHit hit;
                if (Physics.Raycast(ray, out hit))
                {
                    px = (int)math.round(hit.transform.position.y + 3.5);
                    py = (int)math.round(hit.transform.position.x + 3.5);

                    ChessBoardPlacementHandler.Instance.ClearHighlights();

                    string name = hit.transform.name;
                    if (name.StartsWith("Pawn")) InitiateHighlight("Pawn");
                    else if (name.StartsWith("Bishop")) InitiateHighlight("Bishop");
                    else if (name.StartsWith("Knight")) InitiateHighlight("Knight");
                    else if (name.StartsWith("Rook")) InitiateHighlight("Rook");
                    else if (name == "Queen") InitiateHighlight("Queen");
                    else if (name == "King") InitiateHighlight("King");
                }
            }
        }

        public void InitiateHighlight(string pieceType)
        {
            switch (pieceType)
            {
                case "Queen":
                    HighlightBlock(1, 0); HighlightBlock(0, 1); HighlightBlock(1, 1);
                    HighlightBlock(-1, 0); HighlightBlock(0, -1); HighlightBlock(-1, -1);
                    HighlightBlock(-1, 1); HighlightBlock(1, -1);
                    break;

                case "King":
                    Surround(1, 0); Surround(0, 1); Surround(1, 1);
                    Surround(-1, 0); Surround(0, -1); Surround(1, -1);
                    Surround(-1, 1); Surround(-1, -1);
                    break;

                case "Knight":
                    LHighlightBlock(2, 1); LHighlightBlock(2, -1); LHighlightBlock(-2, 1); LHighlightBlock(-2, -1);
                    LHighlightBlock(1, 2); LHighlightBlock(-1, 2); LHighlightBlock(1, -2); LHighlightBlock(-1, -2);
                    break;

                case "Bishop":
                    HighlightBlock(1, 1); HighlightBlock(1, -1); HighlightBlock(-1, 1); HighlightBlock(-1, -1);
                    break;

                case "Rook":
                    HighlightBlock(1, 0); HighlightBlock(0, 1); HighlightBlock(-1, 0); HighlightBlock(0, -1);
                    break;

                case "Pawn":
                    SingleMove(1, 0);
                    break;
            }
        }

        public void IsOccupied(int x, int y)
        {
            GameObject[] allPieces = GameObject.FindGameObjectsWithTag("Black");
            noPiecesOverlap = true;

            GameObject tile = ChessBoardPlacementHandler.Instance.GetTile(x, y);
            int tileX = (int)math.round(tile.transform.position.x + 3.5);
            int tileY = (int)math.round(tile.transform.position.y + 3.5);

            foreach (GameObject piece in allPieces)
            {
                int pieceX = (int)math.round(piece.transform.position.x + 3.5);
                int pieceY = (int)math.round(piece.transform.position.y + 3.5);

                if (pieceX == tileX && pieceY == tileY)
                {
                    noPiecesOverlap = false;
                    break;
                }
            }
        }

        public void HighlightBlock(int dx, int dy)
        {
            int x = px + dx;
            int y = py + dy;

            while (x >= 0 && x < 8 && y >= 0 && y < 8)
            {
                IsOccupied(x, y);
                if (noPiecesOverlap)
                {
                    ChessBoardPlacementHandler.Instance.Highlight(x, y);
                }
                else
                {
                    break;
                }
                x += dx;
                y += dy;
            }
        }

        public void LHighlightBlock(int dx, int dy)
        {
            int x = px + dx;
            int y = py + dy;

            if (x >= 0 && x < 8 && y >= 0 && y < 8)
            {
                IsOccupied(x, y);
                if (noPiecesOverlap)
                {
                    ChessBoardPlacementHandler.Instance.Highlight(x, y);
                }
            }
        }

        public void SingleMove(int dx, int dy)
        {
            int x = px + dx;
            int y = py + dy;

            IsOccupied(x, y);
            if (noPiecesOverlap)
            {
                ChessBoardPlacementHandler.Instance.Highlight(x, y);
                if (px == 1)
                {
                    int x2 = x + dx;
                    IsOccupied(x2, y);
                    if (noPiecesOverlap)
                    {
                        ChessBoardPlacementHandler.Instance.Highlight(x2, y);
                    }
                }
            }
        }

        public void Surround(int dx, int dy)
        {
            int x = px + dx;
            int y = py + dy;

            if (x >= 0 && x < 8 && y >= 0 && y < 8)
            {
                IsOccupied(x, y);
                if (noPiecesOverlap)
                {
                    ChessBoardPlacementHandler.Instance.Highlight(x, y);
                }
            }
        }
    }
}